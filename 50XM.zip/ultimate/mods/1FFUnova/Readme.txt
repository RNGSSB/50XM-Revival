Place the Stage folder in your SD card or in the mods folder of UMM. (remove the readme if umm)
Both should work. Hope works out! God Bless.

Mod by Devory (PowerMarshall)